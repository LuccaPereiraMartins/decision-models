"""Audit the post-hoc FinBERT extension; only train/selection/calibration are loaded."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import sys

import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import softmax
import torch
from filelock import FileLock

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT / 'decision_models'))
from arithmetic import check_breakdown, policy, same  # noqa: E402
from protocol import training_subset  # noqa: E402
from research_runtime import Runtime, verify  # noqa: E402
from schemas import LABELS, annotation, body_hash, load_split  # noqa: E402
from prepare import family, sample  # noqa: E402

HERE = ROOT / 'decision_models'
SPLITS = HERE / 'data/research/benchmark'
BASE = HERE / 'training_runs/research-extension-20261013'
CHECKS = Path(__file__).resolve().parent
receipt = json.loads((BASE / 'receipt.json').read_text())
assert receipt['status'] == 'completed' and receipt['exit_code'] == 0 and receipt['awake_guard_released']
assert not (CHECKS / 'verification.json').exists(), 'Keep any earlier receipt'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


manifest = json.loads((SPLITS / 'manifest.json').read_text())
names = {4000: HERE / 'training_runs/research-core-v1/runs/finbert-lora-ce-w0.0-lr0.0001-n4000-c512',
         16000: BASE / 'finbert-lora-n16000-c512'}
cohorts = {}
for split in ('selection', 'calibration'):
    rows = load_split(SPLITS, split)
    random.Random(42).shuffle(rows)
    cohorts[split] = rows
report, bundle = {}, {'status': receipt['scope'], 'freeze_sha256': receipt['preserved_sha256'][str(HERE / 'training_runs/research-core-v1/freeze.json')],
                     'execution': receipt, 'models': {}}
initial_weights = None
for n, directory in names.items():
    config, _ = verify(directory, manifest)
    assert config['samples'] == n and config['kind'] == 'finbert' and config['adaptation'] == 'lora'
    assert config['max_len'] == 512 and config['seed'] == 42 and config['lora_rank'] == 8
    assert config['epochs'] == 3 and config['class_weight_power'] == 0
    assert config['learning_rate'] == config['encoder_learning_rate'] == 0.0001
    records = training_subset(SPLITS, n)
    identities = [(body_hash(r), annotation(r)['label']) for r in records]
    assert hashlib.sha256(json.dumps(identities).encode()).hexdigest() == config['train_subset_sha256']
    history = json.loads((directory / 'history.json').read_text())
    decision = json.loads((directory / 'decision.json').read_text())
    performance = json.loads((directory / 'performance.json').read_text())
    best = torch.load(directory / 'best.pt', map_location='cpu', weights_only=True)
    last = torch.load(directory / 'last.pt', map_location='cpu', weights_only=True)
    zero = torch.load(directory / 'epoch-zero.pt', map_location='cpu', weights_only=True)
    for checkpoint in (best, last, zero):
        assert all(torch.isfinite(t).all() for t in checkpoint['weights'].values())
    assert set(best['weights']) == set(zero['weights'])
    assert sum(t.numel() for t in best['weights'].values()) == config['trainable_parameters'] == 298755
    assert history['epoch'] == 3 and history['steps'] == n * 3 // 8 and history['offset'] == 0
    assert last['state'] == history and best['state']['epoch'] == history['best_epoch']
    assert history['best_epoch'] == max(history['history'], key=lambda h: h['validation']['macro_f1'])['epoch']
    assert all(torch.equal(best['weights'][k], last['weights'][k]) for k in best['weights'])
    assert history['best_epoch'] == 3
    if initial_weights is None:
        initial_weights = zero['weights']
    else:
        assert all(torch.equal(t, initial_weights[k]) for k, t in zero['weights'].items()), 'Matched pretrained weights'
    row = {'config': {k: v for k, v in config.items() if k != 'split_manifest'}, 'history': history,
           'decision': decision, 'performance': performance,
           'training': [{'body_sha256': body_hash(r), 'reference': annotation(r)['label'], 'family': family(r),
                         'characters': len(r['body'])} for r in records],
           'files_sha256': {name: sha(directory / name) for name in ('config.json','complete.json','best.pt','last.pt',
                            'epoch-zero.pt','selection.json','calibration.json','decision.json','history.json','performance.json')}}
    for split, source in cohorts.items():
        saved = json.loads((directory / (split + '.json')).read_text())
        predictions = saved['predictions']
        assert [(r['body_sha256'],r['group_id'],r['reference']) for r in predictions] == [
            (body_hash(r),r['group_id'],annotation(r)['label']) for r in source]
        for r, original in zip(predictions, source, strict=True):
            assert r['characters'] == len(original['body']) and r['family'] == family(original)
        check_breakdown(predictions, saved['metrics'])
        p = np.array([r['probabilities'] for r in predictions])
        y = np.array([LABELS.index(r['reference']) for r in predictions])
        for key, value in decision['policies'].items():
            discard = (p.argmax(1) == 0) & (p[:,0] >= value['threshold'])
            assert discard.tolist() == [r['discard'][key] for r in predictions]
            same(policy(y,discard), saved['metrics']['overall']['policies'][key])
            if split == 'calibration':
                feasible = [int(((p.argmax(1) == 0) & (p[:,0] >= t)).sum()) for t in np.unique(p[:,0])
                            if policy(y, (p.argmax(1) == 0) & (p[:,0] >= t))['dangerous_miss_rate'] <= float(key)]
                assert int(discard.sum()) == max([0, *feasible])
        # Temperature scaling preserves classes; invert it for the raw-score arithmetic.
        raw = softmax(np.log(p) * decision['temperature'], axis=1)
        raw_rows = [{**r, 'probabilities': vector.tolist(), 'uncertainty': float(1-vector.max()), 'discard': {}}
                    for r, vector in zip(predictions, raw, strict=True)]
        if split == 'selection':
            state = history['history'][history['best_epoch']]['validation']
            same(saved['metrics']['overall']['macro_f1'], state['macro_f1'])
            same(saved['metrics']['overall']['accuracy'], state['agreement'])
            assert saved['metrics']['overall']['confusion_matrix'] == [list(state['confusion_matrix'][k].values()) for k in LABELS]
        if split == 'calibration':
            def loss(log_t):
                v=softmax(np.log(p)*decision['temperature']/np.exp(log_t),axis=1)
                return -np.log(np.maximum(v[np.arange(len(y)),y],1e-12)).mean()
            result=minimize_scalar(loss,bounds=(-3,3),method='bounded')
            chosen=min((0.0,float(result.x),-3.0,3.0),key=loss)
            np.testing.assert_allclose(np.exp(chosen),decision['temperature'],rtol=1e-6)
            assert decision['calibration_sha256'] == hashlib.sha256(json.dumps([
                (body_hash(r),annotation(r)['label']) for r in source]).encode()).hexdigest()
        row[split] = saved
        row[split]['raw_probabilities'] = raw.tolist()
    assert performance['sample'] == [body_hash(r) for r in sample(cohorts['selection'],128)]
    clocks = np.array(performance['latency_seconds']['measurements'])
    assert clocks.shape == (128,) and np.isfinite(clocks).all() and (clocks > 0).all()
    for key, value in [('mean',clocks.mean()),('p50',np.quantile(clocks,.5)),('p95',np.quantile(clocks,.95))]:
        same(performance['latency_seconds'][key],float(value))
    assert history['seconds'] > 0 and performance['training_peak_vram_bytes'] == history['peak_vram_bytes']
    for batch, measurement in performance['batch_throughput'].items():
        same(measurement['documents_per_second'],128/measurement['seconds'])
    bundle['models'][str(n)] = row
    report[str(n)] = {'selected_epoch': history['best_epoch'], 'macro_f1': history['best_f1'],
                      'critical_misses':row['selection']['metrics']['overall']['default_discard']['dangerous_misses']}
    del best, last, zero
small, large = [bundle['models'][str(n)] for n in (4000,16000)]
assert large['training'][:4000] == small['training'], 'Nested training identities and composition'
for key in ('model','revision','source_sha256','versions','max_len','pooling_method','seed','trainable_parameters'):
    assert small['config'][key] == large['config'][key], key

# Replay the completed 16k checkpoint on development cohorts only, under the same GPU lock.
with FileLock(HERE / 'data/research/gpu-job.lock'):
    model = Runtime(names[16000])
    replay = {}
    for split, source in cohorts.items():
        logits = model.logits([r['body'] for r in source])
        expected = large[split]['predictions']
        p = softmax(logits / large['decision']['temperature'], axis=1)
        np.testing.assert_allclose(p, [r['probabilities'] for r in expected], rtol=1e-6, atol=1e-8)
        raw = softmax(logits,axis=1)
        np.testing.assert_allclose(raw,large[split]['raw_probabilities'],rtol=1e-6,atol=1e-8)
        replay[split] = logits.tolist()
        print(f'Checkpoint replay verified: {split}, {len(source)} documents',flush=True)
    (CHECKS / 'replay-logits.json').write_text(json.dumps(replay)+'\n',encoding='utf-8',newline='\n')
for name, expected in receipt['preserved_sha256'].items():
    assert sha(Path(name)) == expected, name
assert sha(BASE/'run.py') == receipt['runner_sha256']
(CHECKS / 'evidence.json').write_text(json.dumps(bundle,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
verification={'status':'verified','utc':datetime.now(timezone.utc).isoformat(),'runs':report,
              'evidence_sha256':sha(CHECKS/'evidence.json'),'verifier_sha256':sha(Path(__file__)),
              'arithmetic_sha256':sha(CHECKS/'arithmetic.py'),'checkpoint_replay_sha256':sha(CHECKS/'replay-logits.json'),
              'checks':['ordered train/selection/calibration identities and nesting','source/runtime/artifact fingerprints',
                        'finite zero/best/final weights and matched initialization','raw checkpoint probabilities on development cohorts',
                        'independent sklearn metrics, critical misses, calibrated probabilities and maximal feasible policies',
                        'checkpoint selection and temperature optimum','performance clocks, sample and memory identities',
                        'unchanged original study and ownership hashes'],
              'limits':'Post-test development choice; selection/calibration fitting evidence only; no new test result'}
(CHECKS/'verification.json').write_text(json.dumps(verification,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(verification),flush=True)
