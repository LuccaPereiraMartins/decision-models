"""Independently audit every reported development metric against the published inputs."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

CHECKS = Path(__file__).resolve().parent
ROOT = CHECKS.parents[4]
sys.path.insert(0, str(ROOT / 'decision_models'))
from arithmetic import check_metrics, same  # noqa: E402
from development import summarize  # noqa: E402

evidence = json.loads((CHECKS / 'evidence.json').read_text())
summary = summarize(evidence)
for name, model in evidence['models'].items():
    for split in ('selection', 'calibration'):
        rows = model[split]['predictions']
        check_metrics(rows, summary['models'][name][split])
        raw = [{**r, 'probabilities': p, 'uncertainty': float(1 - max(p)), 'discard': {}}
               for r, p in zip(rows, model[split]['raw_probabilities'], strict=True)]
        check_metrics(raw, summary['models'][name][split + '_raw'])
        if split == 'selection':
            # Torch FP32 cross-entropy and CPU double log loss have different rounding.
            np.testing.assert_allclose(summary['models'][name][split + '_raw']['log_loss'],
                                       model['history']['history'][model['history']['best_epoch']]['validation']['loss'],
                                       rtol=1e-6, atol=1e-7)
saved_path = ROOT / 'decision_models/training_runs/research-core-v1/report/development-summary.json'
same(summary, json.loads(saved_path.read_text()))
receipt = {'status': 'verified', 'utc': datetime.now(timezone.utc).isoformat(),
           'checks': 'All raw/calibrated development metrics independently reconstructed; renderer summary matches evidence',
           'summary_sha256': hashlib.sha256(saved_path.read_bytes()).hexdigest(),
           'verifier_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'source_sha256': hashlib.sha256((ROOT / 'decision_models/development.py').read_bytes()).hexdigest(),
           'rounding': 'Only Torch FP32 history loss versus CPU double log loss uses rtol=1e-6/atol=1e-7; other metric comparisons use rtol=1e-10/atol=1e-12'}
with (CHECKS / 'summary-verification.json').open('x', encoding='utf-8', newline='\n') as out:
    json.dump(receipt, out, indent=2)
    out.write('\n')
print(json.dumps(receipt), flush=True)
