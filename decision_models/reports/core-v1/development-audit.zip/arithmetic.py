"""Independent sklearn arithmetic; extracted audited functions, no study execution."""
import numpy as np
from sklearn.metrics import confusion_matrix, precision_recall_fscore_support
LABELS = ["routine", "review_worthy", "unclear"]

def same(actual, expected):
    if isinstance(expected, dict):
        assert set(actual) == set(expected), (set(actual), set(expected))
        for key, value in expected.items():
            same(actual[key], value)
    elif isinstance(expected, list):
        assert len(actual) == len(expected)
        for a, e in zip(actual, expected, strict=True):
            same(a, e)
    elif isinstance(expected, float):
        assert np.isfinite(expected) and np.isclose(actual, expected, rtol=1e-10, atol=1e-12), (actual, expected)
    else:
        assert actual == expected, (actual, expected)


def policy(y, mask):
    n, support, misses = int(mask.sum()), int((y == 1).sum()), int(((y == 1) & mask).sum())
    return dict(discarded=n, workload_reduction=n / len(y), review_worthy_support=support,
                dangerous_misses=misses, dangerous_miss_rate=misses / support if support else None,
                discard_contamination=float(((y != 0) & mask).sum() / n) if n else None,
                unclear_discarded=int(((y == 2) & mask).sum()))


def check_metrics(rows, saved):
    y = np.array([LABELS.index(r["reference"]) for r in rows])
    p = np.array([r["probabilities"] for r in rows])
    assert p.shape == (len(rows), 3) and np.isfinite(p).all() and (p >= 0).all() and (p <= 1).all()
    np.testing.assert_allclose(p.sum(1), 1, atol=1e-12, rtol=1e-12)
    pred = p.argmax(1)
    assert [LABELS[i] for i in pred] == [r["prediction"] for r in rows]
    np.testing.assert_allclose(1 - p.max(1), [r["uncertainty"] for r in rows], atol=1e-12)
    precision, recall, f1, support = precision_recall_fscore_support(y, pred, labels=[0, 1, 2], zero_division=0)
    conf, bins, ece = p.max(1), [], 0.0
    for i in range(10):
        mask = (conf >= i / 10) & ((conf < (i + 1) / 10) if i < 9 else (conf <= 1))
        acc = float((y[mask] == pred[mask]).mean()) if mask.any() else None
        confidence = float(conf[mask].mean()) if mask.any() else None
        if mask.any():
            ece += float(mask.mean()) * abs(acc - confidence)
        bins.append(dict(lower=i / 10, upper=(i + 1) / 10, count=int(mask.sum()), accuracy=acc, confidence=confidence))
    expected = dict(count=len(rows), macro_f1=float(f1.mean()), accuracy=float((y == pred).mean()),
                    per_class={label: dict(precision=float(precision[i]), recall=float(recall[i]), f1=float(f1[i]),
                                           support=int(support[i])) for i, label in enumerate(LABELS)},
                    confusion_matrix=confusion_matrix(y, pred, labels=[0, 1, 2]).tolist(), default_discard=policy(y, pred == 0),
                    brier=float(np.square(p - np.eye(3)[y]).sum(1).mean()),
                    log_loss=float(-np.log(np.maximum(p[np.arange(len(y)), y], 1e-12)).mean()),
                    ece_10_bins=ece, calibration_bins=bins,
                    policies={key: policy(y, np.array([r["discard"][key] for r in rows])) for key in rows[0]["discard"]})
    same(saved, expected)


def check_breakdown(rows, saved):
    check_metrics(rows, saved["overall"])
    for key in ("family", "source", "reference_source"):
        values = {r[key] for r in rows}
        assert values == set(saved["by_" + key])
        for value in values:
            check_metrics([r for r in rows if r[key] == value], saved["by_" + key][value])

