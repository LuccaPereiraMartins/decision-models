"""Shared data schemas, labels and Laya task settings."""

from typing import Literal, get_args
import hashlib
import json
import time
from pathlib import Path

from pydantic import BaseModel, ConfigDict


LabelName = Literal["routine", "review_worthy", "unclear"]
LABELS = get_args(LabelName)
BINARY_LABELS = LABELS[:2]
BINARY_TASK = "binary-v2"


def task_labels(metadata=None):
    """A missing task remains the original three-class protocol."""
    metadata = metadata or {}
    task = metadata.get("task_id", "triage-v1")
    if task not in ("triage-v1", BINARY_TASK):
        raise ValueError(f"Unknown reference task: {task}")
    if task == BINARY_TASK and "labels" not in metadata:
        raise ValueError("Binary task requires explicitly ordered labels")
    expected = BINARY_LABELS if task == BINARY_TASK else LABELS
    declared = tuple(metadata.get("labels", expected))
    if declared != expected:
        raise ValueError("Task and ordered labels disagree")
    return declared

# One pinned model and task definition for base inference and supervised adaptation.
LAYA_MODEL = "convaiinnovations/laya"
LAYA_REVISION = "55cf4c4ebb4ebe31b2550e8bdf3bd21b99753851"
LAYA_QUESTIONS = {
    "triage": {
        "type": "choice",
        "instructions": "Classify this financial document for whether an investment analyst should spend time reviewing it.",
        "criteria": {
            "routine": "Ordinary update with no apparent development requiring closer review.",
            "review_worthy": "A potentially significant development that merits closer review.",
            "unclear": "Insufficient or conflicting information to decide.",
        },
    }
}


def task_questions(labels=LABELS):
    if tuple(labels) == LABELS:
        return LAYA_QUESTIONS
    if tuple(labels) != BINARY_LABELS:
        raise ValueError("Unsupported ordered labels")
    return {"triage": {
        "type": "choice",
        "instructions": (
            "Decide whether an investment analyst should review this financial document. "
            "Use the supplied content alone. Route unresolved potentially significant "
            "financial developments to review."
        ),
        "criteria": {
            "routine": "Ordinary or administrative content with no apparent development requiring closer review.",
            "review_worthy": "A potentially significant development, including an unresolved financial development, that merits review.",
        },
    }}

Uncertainty = Literal[0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]


class Annotation(BaseModel):
    model_config = ConfigDict(extra="allow")
    label: LabelName | None = None
    uncertainty: Uncertainty | None = None


class FilingRecord(BaseModel):
    model_config = ConfigDict(extra="allow")
    date: str
    body: str
    llm: Annotation
    human: Annotation
    document_id: str | None = None
    url: str | None = None
    source: str = "sec"
    document_type: str = "8-K"
    event_id: str | None = None
    issuer: str | None = None
    date_precision: Literal["day", "second"] = "day"
    provenance: dict = {}


class LabelOutput(BaseModel):
    label: LabelName
    uncertainty: Uncertainty


class BinaryLabelOutput(BaseModel):
    label: Literal["routine", "review_worthy"]
    uncertainty: Uncertainty


def load_split(directory, name):
    manifest = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
    content = (directory / f"{name}.jsonl").read_bytes()
    expected = manifest["splits"][name]
    if hashlib.sha256(content).hexdigest() != expected["sha256"]:
        raise ValueError(f"Split checksum mismatch: {name}")
    rows = [json.loads(line) for line in content.decode().split("\n") if line.strip()]
    if len(rows) != expected["count"]:
        raise ValueError(f"Split count mismatch: {name}")
    labels = task_labels(manifest)
    if any(annotation(row)["label"] not in labels for row in rows):
        raise ValueError(f"Reference outside the manifest's task: {name}")
    return rows


HERE = Path(__file__).resolve().parent
DATASET = HERE / "data/dataset.json"
SPLITS = HERE / "data/splits"
API_MODEL = HERE / "data/api_model.joblib"


def annotation(record):
    return record["human"] if record["human"]["label"] is not None else record["llm"]


def body_hash(record):
    return hashlib.sha256(record["body"].encode()).hexdigest()


def file_hash(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_records(path):
    """Read the legacy JSON array or a resumable JSONL corpus without dropping metadata."""
    path = Path(path)
    if not path.exists():
        return []
    content = path.read_text(encoding="utf-8")
    # Unicode line separators can be literal source text inside a valid JSON string.
    rows = json.loads(content) if path.suffix == ".json" else [json.loads(line) for line in content.split("\n") if line.strip()]
    return [FilingRecord.model_validate(row).model_dump(exclude_unset=True) for row in rows]


def write_records(records, path):
    path = Path(path)
    if path.suffix == ".json":
        return save(records, path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in records), encoding="utf-8")
    replace_file(temporary, path)


def replace_file(temporary, destination):
    """Atomic replacement, with brief retries for OneDrive file locks."""
    for attempt in range(5):
        try:
            temporary.replace(destination)
            return
        except PermissionError:
            if attempt == 4:
                raise
            time.sleep(1)


def save(value, path=DATASET):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    replace_file(temporary, path)
