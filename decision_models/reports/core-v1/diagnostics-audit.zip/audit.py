"""Independent row-weighted sklearn verification of exploratory group intervals."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.special import softmax
from sklearn.metrics import confusion_matrix, f1_score

root = Path.cwd()
folder = root / "decision_models/data/research/checks/exploratory-diagnostics-20261013"
publication = root / "decision_models/reports/core-v1"
result_path = root / "decision_models/training_runs/research-core-v1/report/diagnostics.json"
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
inputs, result = read(folder / "inputs.json"), read(result_path)
bundle = json.loads(gzip.decompress((publication / "predictions.json.gz").read_bytes()))
details = json.loads(gzip.decompress((publication / "comparison-details.json.gz").read_bytes()))
labels = ["routine", "review_worthy", "unclear"]
rows = bundle["cohort"]
y = np.array([labels.index(r["reference"]) for r in rows])
names = (inputs["primary"], inputs["reference"])
pred = {n: softmax(np.asarray(bundle["models"][n]["logits"]) / details[n]["decision"]["temperature"], axis=1).argmax(1) for n in names}


def check_interval(vector, saved):
    np.testing.assert_allclose(np.quantile(vector, [.025, .975]), [saved["lower"], saved["upper"]], rtol=1e-10, atol=1e-12)
    assert saved["valid_replicates"] == 2000


def row_weighted_draws(mask, binary=False):
    gs, index = np.unique([r["group_id"] for r, take in zip(rows, mask, strict=True) if take], return_inverse=True)
    draws = np.random.default_rng(42).multinomial(len(gs), np.full(len(gs), 1 / len(gs)), size=2000)
    target = (y[mask] != 0).astype(int) if binary else y[mask]
    values, miss, workload = {}, {}, {}
    for n in names:
        guessed = (pred[n][mask] != 0).astype(int) if binary else pred[n][mask]
        vectors, misses, loads = [], [], []
        for draw in draws:
            weights = draw[index]
            vectors.append(f1_score(target, guessed, labels=[0, 1] if binary else [0, 1, 2],
                                    average=None, sample_weight=weights, zero_division=0))
            if binary:
                misses.append(weights[(target == 1) & (guessed == 0)].sum() / weights[target == 1].sum())
                loads.append(weights[guessed == 0].sum() / weights.sum())
        values[n], miss[n], workload[n] = np.array(vectors), np.array(misses), np.array(loads)
    return values, miss, workload


all_rows = np.ones(len(rows), dtype=bool)
vectors, _, _ = row_weighted_draws(all_rows)
for i, row in enumerate(result["class_decomposition"]):
    point = [f1_score(y, pred[n], labels=[0, 1, 2], average=None)[i] for n in names]
    np.testing.assert_allclose(point, [row["primary_f1"], row["reference_f1"]])
    check_interval((vectors[names[0]][:, i] - vectors[names[1]][:, i]) / 3, row["interval"])
binary, miss, workload = row_weighted_draws(all_rows, binary=True)
for n in names:
    np.testing.assert_array_equal(confusion_matrix(y != 0, pred[n] != 0, labels=[False, True]), result["routing"][n]["confusion_matrix"])
    check_interval(binary[n].mean(1), result["routing"][n]["intervals"]["macro_f1"])
    check_interval(miss[n], result["routing"][n]["intervals"]["review_required_miss_rate"])
    check_interval(workload[n], result["routing"][n]["intervals"]["workload_reduction"])
for key, values in [("macro_f1", {n: binary[n].mean(1) for n in names}), ("review_required_miss_rate", miss), ("workload_reduction", workload)]:
    check_interval(values[names[0]] - values[names[1]], result["paired_routing_intervals"][key])
lengths = np.array([r["characters"] for r in rows])
cuts = np.quantile(inputs["selection_characters"], [.25, .5, .75])
np.testing.assert_array_equal(cuts, result["methods"]["length_cutpoints_characters"])
masks = [lengths < cuts[0], (lengths >= cuts[0]) & (lengths < cuts[1]),
         (lengths >= cuts[1]) & (lengths < cuts[2]), lengths >= cuts[2]]
slices = [(r, np.array([row["family"] == r["slice"] for row in rows])) for r in result["family_slices"]]
slices += list(zip(result["length_slices"], masks, strict=True))
for row, mask in slices:
    assert int(mask.sum()) == row["count"]
    if not mask.any():
        continue
    values, _, _ = row_weighted_draws(mask)
    check_interval(values[names[0]].mean(1) - values[names[1]].mean(1), row["paired_intervals"]["macro_f1"])
    observed = [f1_score(y[mask], pred[n][mask], labels=[0, 1, 2], average="macro", zero_division=0) for n in names]
    np.testing.assert_allclose(observed[0] - observed[1], row["macro_f1_delta"])
ma, mb = (y == 1) & (pred[names[0]] == 0), (y == 1) & (pred[names[1]] == 0)
assert [int((ma & mb).sum()), int((ma & ~mb).sum()), int((mb & ~ma).sum())] == [result["critical_miss_overlap"][k] for k in ("both", "primary_only", "reference_only")]
receipt = {"status": "verified", "utc": datetime.now(timezone.utc).isoformat(),
           "diagnostics_sha256": hashlib.sha256(result_path.read_bytes()).hexdigest(),
           "verifier_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           "checks": ["all class contributions and routing intervals", "all source/length point metrics and intervals",
                      "independent row-level sample weights for every 2000-draw slice", "length boundaries and miss overlap"],
           "models_unchanged": True, "limits": "Post-hoc, one trained seed, no multiplicity adjustment or independent human labels"}
with (folder / "verification.json").open("x", encoding="utf-8", newline="\n") as stream:
    stream.write(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
