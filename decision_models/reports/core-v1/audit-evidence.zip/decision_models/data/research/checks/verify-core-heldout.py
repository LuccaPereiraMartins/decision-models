"""Independent arithmetic and identity audit; run after frozen inference completes."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.special import softmax
from sklearn.metrics import confusion_matrix, precision_recall_fscore_support

ROOT = Path(__file__).resolve().parents[4]
STUDY = ROOT / "decision_models/training_runs/research-core-v1"
SPLITS = ROOT / "decision_models/data/research/benchmark"
LABELS = ["routine", "review_worthy", "unclear"]


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def same(actual, expected):
    if isinstance(expected, dict):
        assert set(actual) == set(expected), (set(actual), set(expected))
        for key, value in expected.items():
            same(actual[key], value)
    elif isinstance(expected, list):
        assert len(actual) == len(expected)
        for a, e in zip(actual, expected, strict=True):
            same(a, e)
    elif isinstance(expected, float):
        assert np.isfinite(expected) and np.isclose(actual, expected, rtol=1e-10, atol=1e-12), (actual, expected)
    else:
        assert actual == expected, (actual, expected)


def policy(y, mask):
    n, support, misses = int(mask.sum()), int((y == 1).sum()), int(((y == 1) & mask).sum())
    return dict(discarded=n, workload_reduction=n / len(y), review_worthy_support=support,
                dangerous_misses=misses, dangerous_miss_rate=misses / support if support else None,
                discard_contamination=float(((y != 0) & mask).sum() / n) if n else None,
                unclear_discarded=int(((y == 2) & mask).sum()))


def check_metrics(rows, saved):
    y = np.array([LABELS.index(r["reference"]) for r in rows])
    p = np.array([r["probabilities"] for r in rows])
    assert p.shape == (len(rows), 3) and np.isfinite(p).all() and (p >= 0).all() and (p <= 1).all()
    np.testing.assert_allclose(p.sum(1), 1, atol=1e-12, rtol=1e-12)
    pred = p.argmax(1)
    assert [LABELS[i] for i in pred] == [r["prediction"] for r in rows]
    np.testing.assert_allclose(1 - p.max(1), [r["uncertainty"] for r in rows], atol=1e-12)
    precision, recall, f1, support = precision_recall_fscore_support(y, pred, labels=[0, 1, 2], zero_division=0)
    conf, bins, ece = p.max(1), [], 0.0
    for i in range(10):
        mask = (conf >= i / 10) & ((conf < (i + 1) / 10) if i < 9 else (conf <= 1))
        acc = float((y[mask] == pred[mask]).mean()) if mask.any() else None
        confidence = float(conf[mask].mean()) if mask.any() else None
        if mask.any():
            ece += float(mask.mean()) * abs(acc - confidence)
        bins.append(dict(lower=i / 10, upper=(i + 1) / 10, count=int(mask.sum()), accuracy=acc, confidence=confidence))
    expected = dict(count=len(rows), macro_f1=float(f1.mean()), accuracy=float((y == pred).mean()),
                    per_class={label: dict(precision=float(precision[i]), recall=float(recall[i]), f1=float(f1[i]),
                                           support=int(support[i])) for i, label in enumerate(LABELS)},
                    confusion_matrix=confusion_matrix(y, pred, labels=[0, 1, 2]).tolist(), default_discard=policy(y, pred == 0),
                    brier=float(np.square(p - np.eye(3)[y]).sum(1).mean()),
                    log_loss=float(-np.log(np.maximum(p[np.arange(len(y)), y], 1e-12)).mean()),
                    ece_10_bins=ece, calibration_bins=bins,
                    policies={key: policy(y, np.array([r["discard"][key] for r in rows])) for key in rows[0]["discard"]})
    same(saved, expected)


def check_breakdown(rows, saved):
    check_metrics(rows, saved["overall"])
    for key in ("family", "source", "reference_source"):
        values = {r[key] for r in rows}
        assert values == set(saved["by_" + key])
        for value in values:
            check_metrics([r for r in rows if r[key] == value], saved["by_" + key][value])


def bounds(values):
    values = values[np.isfinite(values)]
    lo, hi = np.quantile(values, [0.025, 0.975]) if len(values) else (None, None)
    return dict(lower=float(lo) if lo is not None else None, upper=float(hi) if hi is not None else None,
                valid_replicates=len(values))


freeze, results = read(STUDY / "freeze.json"), read(STUDY / "results.json")
freeze_hash = digest(STUDY / "freeze.json")
assert freeze_hash == "0be83dda3a2936694d3768c1a15723fbd99b6cb895299d5458771ec32d6c664a"
manifest = read(SPLITS / "manifest.json")
assert digest(SPLITS / "test.jsonl") == manifest["splits"]["test"]["sha256"]
records = [json.loads(line) for line in (SPLITS / "test.jsonl").read_text(encoding="utf-8").split("\n") if line]
identities = [(hashlib.sha256(r["body"].encode()).hexdigest(), r["group_id"], r["llm"]["label"]) for r in records]
assert len(records) == 1800 and all(r["human"]["label"] is None for r in records)
assert Counter(r["llm"]["label"] for r in records) == {"routine": 301, "review_worthy": 1292, "unclear": 207}
same(read(STUDY / "test-started.json"), {"freeze_sha256": freeze_hash})
owner = read(SPLITS / "test-evaluation.json")
assert owner["freeze_sha256"] == freeze_hash and owner["manifest_sha256"] == digest(SPLITS / "manifest.json")
assert set(results["test_artifacts"]) == set(freeze["entries"]) and len(freeze["entries"]) == 64
groups = sorted({r["group_id"] for r in records})
index = {g: i for i, g in enumerate(groups)}
gidx = np.array([index[r["group_id"]] for r in records])
draws = np.random.default_rng(42).multinomial(len(groups), [1 / len(groups)] * len(groups), size=2000)
distributions, verified = {}, {}
for name, entry in freeze["entries"].items():
    path = STUDY / "test" / (name + ".json")
    artifact = digest(path)
    assert results["test_artifacts"][name] == artifact
    same(read(STUDY / "test" / (name + ".complete.json")), {"freeze_sha256": freeze_hash, "result_sha256": artifact})
    result = read(path)
    assert result["freeze_sha256"] == freeze_hash
    rows = result["predictions"]
    assert [(r["body_sha256"], r["group_id"], r["reference"]) for r in rows] == identities
    assert all(r["reference_source"] == "teacher" for r in rows)
    for row, record in zip(rows, records, strict=True):
        source, kind = record.get("source", "sec"), record.get("document_type", "8-K")
        family = {"8-K": "8k", "6-K": "6k", "corporate_release": "releases"}[kind] if source == "sec" else "news" if kind == "news" else source
        assert (row["date"], row["source"], row["document_type"], row["characters"], row["family"], row["teacher_uncertainty"]) == (record["date"], source, kind, len(record["body"]), family, record["llm"].get("uncertainty"))
    cache = [json.loads(line) for line in (STUDY / "test" / (name + "-logits.jsonl")).read_text(encoding="utf-8").split("\n") if line]
    assert len(cache) == len(rows) and [r["body_sha256"] for r in cache] == [r[0] for r in identities]
    logits = np.array([r["logits"] for r in cache])
    assert logits.shape == (1800, 3) and np.isfinite(logits).all()
    decision = read(STUDY / entry["directory"] / "decision.json")
    np.testing.assert_allclose(softmax(logits / decision["temperature"], axis=1), [r["probabilities"] for r in rows], rtol=1e-12, atol=1e-12)
    assert all(np.isfinite(r["seconds"]) and r["seconds"] > 0 for r in cache)
    assert [r["seconds"] for r in cache] == [r["seconds"] for r in rows]
    same(result["inference_seconds"], float(sum(r["seconds"] for r in cache)))
    raw = softmax(logits, axis=1)
    raw_rows = [{**r, "prediction": LABELS[raw[i].argmax()], "probabilities": raw[i].tolist(),
                 "uncertainty": float(1 - raw[i].max()), "discard": {}} for i, r in enumerate(rows)]
    for r in rows:
        vector = np.array(r["probabilities"])
        same(r["discard"], {k: bool(vector.argmax() == 0 and vector[0] >= v["threshold"]) for k, v in decision["policies"].items()})
    check_breakdown(rows, result["metrics"])
    check_breakdown(raw_rows, result["raw_metrics"])
    same(results["models"][name]["metrics"], result["metrics"]["overall"])
    same(results["models"][name]["default_dangerous_misses"], [r["body_sha256"] for r in rows if r["reference"] == "review_worthy" and r["prediction"] == "routine"])
    y, pred = np.array([LABELS.index(r["reference"]) for r in rows]), np.array([LABELS.index(r["prediction"]) for r in rows])
    # Independent vectorized construction of event-group confusion counts.
    counts = np.bincount(gidx * 9 + y * 3 + pred, minlength=len(groups) * 9).reshape(len(groups), 9)
    cms = (draws @ counts).reshape(2000, 3, 3)
    true_n, pred_n = cms.sum(2), cms.sum(1)
    diag = cms[:, np.arange(3), np.arange(3)]
    values = dict(macro_f1=np.divide(2 * diag, true_n + pred_n, out=np.zeros_like(diag, dtype=float), where=true_n + pred_n > 0).mean(1),
                  dangerous_miss_rate=np.divide(cms[:, 1, 0], true_n[:, 1], out=np.full(2000, np.nan), where=true_n[:, 1] > 0))
    total = draws @ np.bincount(gidx, minlength=len(groups))
    for key in rows[0]["discard"]:
        d = np.array([r["discard"][key] for r in rows])
        n_discard = draws @ np.bincount(gidx[d], minlength=len(groups))
        n_miss = draws @ np.bincount(gidx[d & (y == 1)], minlength=len(groups))
        values["workload_" + key] = n_discard / total
        values["dangerous_miss_rate_" + key] = np.divide(n_miss, true_n[:, 1], out=np.full(2000, np.nan), where=true_n[:, 1] > 0)
    distributions[name] = values
    verified[name] = dict(result_sha256=artifact, count=len(rows), macro_f1=result["metrics"]["overall"]["macro_f1"],
                          critical_misses=result["metrics"]["overall"]["default_discard"]["dangerous_misses"])

bootstrap = read(STUDY / "bootstrap.json")
assert digest(STUDY / "bootstrap.json") == results["bootstrap_sha256"]
assert bootstrap["groups"] == len(groups) and bootstrap["documents"] == 1800 and bootstrap["repeats"] == 2000 and bootstrap["seed"] == 42
reference = freeze["primary_linear"]
assert bootstrap["reference"] == reference
for name, values in distributions.items():
    expected = {metric: bounds(v) for metric, v in values.items()}
    expected["paired_delta_vs_reference"] = {metric: bounds(v - distributions[reference][metric]) for metric, v in values.items()}
    same(bootstrap["models"][name], expected)
for contrast in bootstrap["contrasts"].values():
    same(contrast["metrics"], {metric: bounds(v - distributions[contrast["right"]][metric])
                               for metric, v in distributions[contrast["left"]].items()})
assert digest(STUDY / "matched-coverage.json") == results["matched_coverage_sha256"]
matched = read(STUDY / "matched-coverage.json")
assert matched["documents"] == 0 and matched["bootstrap"] is None and set(matched["models"]) == set(verified)
assert all(v["overall"] == {"count": 0} for v in matched["models"].values())
receipt = dict(status="verified", utc=datetime.now(timezone.utc).isoformat(), freeze_sha256=freeze_hash,
               results_sha256=digest(STUDY / "results.json"), verifier_sha256=digest(Path(__file__)),
               groups=len(groups), documents=1800, verified=verified,
               checks=["ordered cohort and freeze ownership", "raw/calibrated probabilities and all overall/source/family metrics",
                       "frozen discard decisions and confusion/FN/support", "cache identity and elapsed arithmetic",
                       "all shared-draw group intervals, primary paired delta and declared contrasts", "result/completion/statistics hashes"],
               limits="Conditional on one trained seed; no independent human labels; no multiplicity correction")
target = Path(__file__).with_name("core-heldout-verification-20261013.json")
with target.open("x", encoding="utf-8") as stream:
    stream.write(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({k: v for k, v in receipt.items() if k != "verified"}))
