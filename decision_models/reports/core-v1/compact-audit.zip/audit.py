"""Verify BGE development evidence; never load or evaluate the original test cohort."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import sys

import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import softmax
from sklearn.metrics import f1_score
import torch
from filelock import FileLock

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT / 'decision_models'))
from arithmetic import check_breakdown, policy, same  # noqa: E402
from protocol import training_subset  # noqa: E402
from research_runtime import Runtime, verify  # noqa: E402
from schemas import LABELS, annotation, body_hash, load_split  # noqa: E402
from prepare import family, sample  # noqa: E402

HERE = ROOT / 'decision_models'
SPLITS = HERE / 'data/research/benchmark'
BASE = HERE / 'training_runs/research-compact-extension-20261013'
CHECKS = Path(__file__).resolve().parent
receipt = json.loads((BASE / 'receipt.json').read_text())
assert receipt['status'] == 'completed' and receipt['exit_code'] == 0 and receipt['awake_guard_released']
assert not (CHECKS / 'verification.json').exists()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


manifest = json.loads((SPLITS / 'manifest.json').read_text())
paths = {'bge_lora': BASE / 'bge-lora-n4000-c512',
         'finbert_lora': HERE / 'training_runs/research-core-v1/runs/finbert-lora-ce-w0.0-lr0.0001-n4000-c512',
         'bge_frozen': HERE / 'training_runs/research-study/runs/bge-logistic-n4000'}
records = training_subset(SPLITS, 4000)
identities = [(body_hash(r), annotation(r)['label']) for r in records]
train_sha = hashlib.sha256(json.dumps(identities).encode()).hexdigest()
cohorts = {split: load_split(SPLITS, split) for split in ('selection', 'calibration')}
bundle = {'status': receipt['scope'], 'execution': receipt,
          'freeze_sha256': receipt['preserved_sha256'][str(HERE / 'training_runs/research-core-v1/freeze.json')],
          'training': [{'body_sha256': body_hash(r), 'reference': annotation(r)['label'],
                        'family': family(r), 'characters': len(r['body'])} for r in records], 'models': {}}
for name, directory in paths.items():
    config, artifact = verify(directory, manifest)
    assert config['samples'] == 4000 and config['train_subset_sha256'] == train_sha
    neural = config['family'] == 'research_neural'
    if neural:
        assert config['seed'] == 42 and config['epochs'] == 3 and config['max_len'] == 512
        assert config['adaptation'] == 'lora' and config['lora_rank'] == 8 and config['class_weight_power'] == 0
        assert config['learning_rate'] == config['encoder_learning_rate'] == 0.0001
    names = ['config.json', 'complete.json', 'decision.json', 'selection.json', 'calibration.json', 'performance.json', artifact]
    entry = {'config': {k:v for k,v in config.items() if k != 'split_manifest'},
             'decision': json.loads((directory / 'decision.json').read_text()),
             'performance': json.loads((directory / 'performance.json').read_text())}
    if neural:
        names += ['history.json', 'epoch-zero.pt', 'last.pt']
        history = json.loads((directory / 'history.json').read_text())
        entry['history'] = history
        best = torch.load(directory / 'best.pt', map_location='cpu', weights_only=True)
        last = torch.load(directory / 'last.pt', map_location='cpu', weights_only=True)
        zero = torch.load(directory / 'epoch-zero.pt', map_location='cpu', weights_only=True)
        for checkpoint in (best, last, zero):
            assert all(torch.isfinite(t).all() for t in checkpoint['weights'].values())
            assert checkpoint['config'] == config
        assert set(best['weights']) == set(zero['weights']) == set(last['weights'])
        assert sum(t.numel() for t in best['weights'].values()) == config['trainable_parameters']
        assert history['epoch'] == 3 and history['offset'] == 0 and history['steps'] == 1500
        assert last['state'] == history and best['state']['epoch'] == history['best_epoch']
        assert history['best_epoch'] == max(history['history'], key=lambda h:h['validation']['macro_f1'])['epoch']
        if name == 'bge_lora':
            assert history['best_epoch'] == 2 and config['trainable_parameters'] == 149379
            assert any(not torch.equal(t,last['weights'][k]) for k,t in best['weights'].items())
        del best, last, zero
    entry['files_sha256'] = {n: sha(directory / n) for n in names}
    for split, original in cohorts.items():
        source = list(original)
        if neural:
            random.Random(42).shuffle(source)
        saved = json.loads((directory / (split + '.json')).read_text())
        rows = saved['predictions']
        assert [(r['body_sha256'],r['group_id'],r['reference']) for r in rows] == [
            (body_hash(r),r['group_id'],annotation(r)['label']) for r in source]
        assert all(r['characters'] == len(s['body']) and r['family'] == family(s) for r,s in zip(rows,source,strict=True))
        check_breakdown(rows, saved['metrics'])
        p = np.array([r['probabilities'] for r in rows])
        y = np.array([LABELS.index(r['reference']) for r in rows])
        decision = entry['decision']
        for key, value in decision['policies'].items():
            mask = (p.argmax(1) == 0) & (p[:,0] >= value['threshold'])
            assert mask.tolist() == [r['discard'][key] for r in rows]
            same(policy(y,mask), saved['metrics']['overall']['policies'][key])
            if split == 'calibration':
                candidates = [int(((p.argmax(1) == 0) & (p[:,0] >= t)).sum()) for t in np.unique(p[:,0])
                              if policy(y,(p.argmax(1) == 0) & (p[:,0] >= t))['dangerous_miss_rate'] <= float(key)]
                assert int(mask.sum()) == max([0,*candidates])
        raw = softmax(np.log(p) * decision['temperature'], axis=1)
        if split == 'selection' and neural:
            state = history['history'][history['best_epoch']]['validation']
            same(saved['metrics']['overall']['macro_f1'], state['macro_f1'])
            same(saved['metrics']['overall']['accuracy'], state['agreement'])
            assert saved['metrics']['overall']['confusion_matrix'] == [list(state['confusion_matrix'][k].values()) for k in LABELS]
        if split == 'calibration':
            def loss(log_t):
                v = softmax(np.log(p)*decision['temperature']/np.exp(log_t),axis=1)
                return -np.log(np.maximum(v[np.arange(len(y)),y],1e-12)).mean()
            optimum = minimize_scalar(loss,bounds=(-3,3),method='bounded')
            chosen = min((0.0,float(optimum.x),-3.0,3.0),key=loss)
            np.testing.assert_allclose(np.exp(chosen),decision['temperature'],rtol=1e-6)
            assert decision['calibration_sha256'] == hashlib.sha256(json.dumps([
                (body_hash(r),annotation(r)['label']) for r in source]).encode()).hexdigest()
        # Publish a common identity order while preserving each original order for replay.
        order = sorted(range(len(rows)),key=lambda i:rows[i]['body_sha256'])
        entry[split] = {**saved, 'predictions': [rows[i] for i in order],
                        'raw_probabilities': [raw[i].tolist() for i in order],
                        'original_body_order': [r['body_sha256'] for r in rows]}
    perf = entry['performance']
    assert perf['sample'] == [body_hash(r) for r in sample(cohorts['selection'],128)]
    clocks = np.array(perf['latency_seconds']['measurements'])
    assert clocks.shape == (128,) and np.isfinite(clocks).all() and (clocks > 0).all()
    for key,value in [('mean',clocks.mean()),('p50',np.quantile(clocks,.5)),('p95',np.quantile(clocks,.95))]:
        same(perf['latency_seconds'][key],float(value))
    for batch,value in perf['batch_throughput'].items():
        same(value['documents_per_second'],128/value['seconds'])
    if neural:
        assert perf['training_peak_vram_bytes'] == history['peak_vram_bytes'] and history['seconds'] > 0
    bundle['models'][name] = entry
for key in ('seed','epochs','max_len','lora_rank','loss_kind','class_weight_power','learning_rate','encoder_learning_rate','pooling_method'):
    assert bundle['models']['bge_lora']['config'][key] == bundle['models']['finbert_lora']['config'][key]

with FileLock(HERE / 'data/research/gpu-job.lock'):
    model = Runtime(paths['bge_lora'])
    replay = {}
    for split, source in cohorts.items():
        source = sorted(source,key=body_hash)
        logits = model.logits([r['body'] for r in source])
        expected = bundle['models']['bge_lora'][split]
        p = softmax(logits / bundle['models']['bge_lora']['decision']['temperature'],axis=1)
        np.testing.assert_allclose(p,[r['probabilities'] for r in expected['predictions']],rtol=1e-6,atol=1e-8)
        np.testing.assert_allclose(softmax(logits,axis=1),expected['raw_probabilities'],rtol=1e-6,atol=1e-8)
        replay[split] = logits.tolist()
        print(f'Best checkpoint replay verified: {split}, {len(source)} documents',flush=True)
    zero = torch.load(paths['bge_lora'] / 'epoch-zero.pt', map_location='cpu',weights_only=True)
    model.model.load_state_dict(zero['weights'],strict=False)
    source = sorted(cohorts['selection'],key=body_hash)
    logits = model.logits([r['body'] for r in source])
    truth = np.array([LABELS.index(annotation(r)['label']) for r in source])
    score = f1_score(truth,logits.argmax(1),labels=[0,1,2],average='macro',zero_division=0)
    same(float(score),bundle['models']['bge_lora']['history']['history'][0]['validation']['macro_f1'])
    replay['epoch_zero_selection'] = logits.tolist()
    bundle['epoch_zero_selection'] = {'cohort': bundle['models']['bge_lora']['selection']['predictions'],
                                      'probabilities': softmax(logits,axis=1).tolist()}
    print('Matched epoch-zero selection replay verified',flush=True)
(CHECKS / 'replay-logits.json').write_text(json.dumps(replay)+'\n',encoding='utf-8',newline='\n')
for name,expected in receipt['preserved_sha256'].items():
    assert sha(Path(name)) == expected,name
assert sha(BASE / 'run.py') == receipt['runner_sha256']
(CHECKS / 'evidence.json').write_text(json.dumps(bundle,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
verification = {'status':'verified','utc':datetime.now(timezone.utc).isoformat(),
                'evidence_sha256':sha(CHECKS/'evidence.json'),'verifier_sha256':sha(Path(__file__)),
                'arithmetic_sha256':sha(CHECKS/'arithmetic.py'),'replay_sha256':sha(CHECKS/'replay-logits.json'),
                'checks':['artifact/source/runtime and exact matched 4k subset','finite zero/best/final checkpoints and epoch-2 selection',
                          'all ordered development identities and raw/calibrated metric/policy/temperature arithmetic',
                          'best checkpoint and matched epoch-zero replay on development only','resource clocks and shared timing sample',
                          'original core and completed FinBERT hashes unchanged'],
                'limits':'Post-test development systems comparison; no new test or causal architecture/adaptation claim'}
(CHECKS/'verification.json').write_text(json.dumps(verification,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(verification),flush=True)
