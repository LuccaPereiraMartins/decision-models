"""One bounded compact-encoder development fit; never reopen the published test study."""
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = ROOT / 'decision_models'
sys.path.insert(0, str(HERE))
from schemas import save  # noqa: E402

OUTPUT = Path(__file__).resolve().parent
CUTOFF = datetime.fromisoformat('2026-10-13T16:00:00+00:00')
RECIPE = OUTPUT / 'bge-lora-n4000-c512'
SPLITS = HERE / 'data/research/benchmark'
CORE = HERE / 'training_runs/research-core-v1'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert not (OUTPUT / 'receipt.json').exists(), 'Do not overwrite an earlier extension run'
assert not RECIPE.exists(), 'Start this development fit afresh'
assert datetime.now(timezone.utc) < CUTOFF
paths = [CORE / n for n in ('plan.json', 'state.json', 'selection.json', 'freeze.json', 'results.json', 'bootstrap.json')]
paths += [SPLITS / n for n in ('manifest.json', 'subsets.json', 'train.jsonl', 'selection.jsonl', 'calibration.jsonl', 'test-evaluation.json')]
paths += [HERE / 'training_runs/research-extension-20261013/receipt.json']
paths += [HERE / 'training_runs/research-extension-20261013/finbert-lora-n16000-c512' / n for n in ('config.json', 'complete.json', 'best.pt', 'selection.json', 'calibration.json')]
preserved = {str(p): digest(p) for p in paths}
assert preserved[str(CORE / 'freeze.json')] == '0be83dda3a2936694d3768c1a15723fbd99b6cb895299d5458771ec32d6c664a'
command = [sys.executable, '-u', str(HERE / 'train.py'), '--model', 'bge', '--adaptation', 'lora',
           '--lora-rank', '8', '--samples', '4000', '--context', '512', '--objective', 'ce',
           '--class-weight-power', '0', '--learning-rate', '0.0001', '--encoder-learning-rate', '0.0001',
           '--epochs', '3', '--window-batch', '8', '--splits', str(SPLITS), '--output', str(RECIPE)]
receipt = {
    'status': 'starting', 'controller_pid': os.getpid(), 'started_utc': datetime.now(timezone.utc).isoformat(),
    'compute_cutoff_utc': CUTOFF.isoformat(), 'report_deadline_utc': '2026-10-13T17:00:00+00:00',
    'scope': 'Post-hoc development experiment using train/selection/calibration only; no original holdout evaluation',
    'question': 'Does compact BGE LoRA at 4000 documents offer a useful quality/resource tradeoff against FinBERT LoRA and frozen BGE?',
    'command': command, 'runner_sha256': digest(Path(__file__)), 'preserved_sha256': preserved,
    'git_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'api_cost_usd': 0.0, 'workers': 1, 'future_test': 'Fresh held-out data required; absent from the 64 frozen comparisons',
}
save(receipt, OUTPUT / 'receipt.json')
awake = ctypes.WinDLL('kernel32', use_last_error=True).SetThreadExecutionState
awake.argtypes = [ctypes.c_uint32]
awake.restype = ctypes.c_uint32
child = None
try:
    assert awake(0x80000001), 'Cannot prevent idle sleep during this bounded job'
    with (OUTPUT / 'training.log').open('x', encoding='utf-8') as log:
        child = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        receipt.update(status='running', worker_pid=child.pid)
        save(receipt, OUTPUT / 'receipt.json')
        while child.poll() is None:
            if datetime.now(timezone.utc) >= CUTOFF:
                child.terminate()
                child.wait(timeout=30)
                receipt['status'] = 'stopped_at_cutoff'
                break
            time.sleep(5)
        receipt['exit_code'] = child.returncode
        if receipt['status'] != 'stopped_at_cutoff':
            receipt['status'] = 'completed' if child.returncode == 0 and (RECIPE / 'complete.json').exists() else 'failed'
    assert all(digest(Path(p)) == h for p, h in preserved.items()), 'Original study or benchmark changed'
    receipt['preserved_hashes_verified'] = True
except Exception as exc:
    receipt.update(status='needs_attention', error=str(exc))
    raise
finally:
    if child is not None and child.poll() is None:
        child.terminate()
        child.wait(timeout=30)
    awake(0x80000000)
    receipt.update(finished_utc=datetime.now(timezone.utc).isoformat(), awake_guard_released=True)
    save(receipt, OUTPUT / 'receipt.json')
    print(json.dumps(receipt), flush=True)
