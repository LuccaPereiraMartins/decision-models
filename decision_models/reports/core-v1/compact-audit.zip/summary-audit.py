"""Independent raw/calibrated and epoch-zero arithmetic for the compact report section."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

CHECKS = Path(__file__).resolve().parent
ROOT = CHECKS.parents[4]
sys.path.insert(0, str(ROOT / 'decision_models'))
from arithmetic import check_metrics, same  # noqa: E402
from compact import summarize  # noqa: E402
from schemas import LABELS  # noqa: E402

evidence = json.loads((CHECKS / 'evidence.json').read_text())
summary = summarize(evidence)
for name, model in evidence['models'].items():
    for split in ('selection', 'calibration'):
        rows = model[split]['predictions']
        check_metrics(rows, summary['models'][name][split])
        raw = [{**r, 'probabilities': p, 'uncertainty': float(1-max(p)), 'discard': {}}
               for r,p in zip(rows,model[split]['raw_probabilities'],strict=True)]
        check_metrics(raw, summary['models'][name][split+'_raw'])
        if split == 'selection' and 'history' in model:
            np.testing.assert_allclose(summary['models'][name][split+'_raw']['log_loss'],
                                       model['history']['history'][model['history']['best_epoch']]['validation']['loss'],
                                       rtol=1e-6,atol=1e-7)
zero = evidence['epoch_zero_selection']
zero_rows = [{**r, 'probabilities': p, 'prediction': LABELS[np.argmax(p)], 'uncertainty': float(1-max(p)), 'discard': {}}
             for r,p in zip(zero['cohort'],zero['probabilities'],strict=True)]
check_metrics(zero_rows, summary['epoch_zero_selection'])
path = ROOT / 'decision_models/training_runs/research-core-v1/report/compact-summary.json'
same(summary,json.loads(path.read_text()))
receipt = {'status':'verified','utc':datetime.now(timezone.utc).isoformat(),
           'checks':'All raw/calibrated and matched epoch-zero metrics independently reconstructed; renderer summary matches evidence',
           'summary_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
           'verifier_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'source_sha256':hashlib.sha256((ROOT/'decision_models/compact.py').read_bytes()).hexdigest(),
           'rounding':'Only Torch FP32 history loss versus CPU double log loss uses rtol=1e-6/atol=1e-7; other metric checks use rtol=1e-10/atol=1e-12'}
with (CHECKS/'summary-verification.json').open('x',encoding='utf-8',newline='\n') as out:
    json.dump(receipt,out,indent=2);out.write('\n')
print(json.dumps(receipt),flush=True)
